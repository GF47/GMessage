﻿using GMessage;
using GRT;
using System;
using System.Collections.Generic;
using System.Text;
$if$ ($targetframeworkversion$ >= 4.5)using System.Threading.Tasks;
$endif$using UnityEngine;

namespace Modules.$modulename$
{
    public class $modulename$View : Listener<$modulename$Module>
    {
        public override $modulename$Module GetDispatcher() => Dispatcher.Instance<$modulename$Module>(ModuleID.$modulename$_Module);

        public override void Receive(IMessage message)
        {
            throw new NotImplementedException();
        }
    }
}

namespace GMessage
{
    public static partial class DefinedID
    {
    }
}
