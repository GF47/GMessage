﻿using GMessage;
using GRT;
using System;
using System.Collections.Generic;
using System.Text;
$if$ ($targetframeworkversion$ >= 4.5)using System.Threading.Tasks;
$endif$using UnityEngine;

namespace Modules.$modulename$
{
    public class $modulename$Module : Dispatcher
    {
        public override IDispatcher GetDispatcher()
        {
            throw new NotImplementedException();
        }
    }
}

namespace GMessage
{
    public static partial class ModuleID
    {
        /// <summary> $modulename$ 模块 </summary>
        public const int $modulename$_Module = 233;
    }
}
